import abi from "./Transactions.json";

export const contractAddress = "0xDe69047620a548A45677FA13d43e3bf980c0d808";
export const contractABI = abi.abi;

//current address of the smart contract that is deployed on the BlockChain
